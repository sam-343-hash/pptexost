import json

import pytest
from pptx import Presentation
from pptx.util import Inches, Pt

from ppt_analyzer import analyze_file
from ppt_analyzer.cli import main


@pytest.fixture()
def deck(tmp_path):
    prs = Presentation()
    # 1: good slide, with title + notes
    s1 = prs.slides.add_slide(prs.slide_layouts[1])
    s1.shapes.title.text = "Welcome"
    s1.placeholders[1].text = "Short and sweet"
    s1.notes_slide.notes_text_frame.text = "Say hello to everyone."
    # 2: no title, tiny font, text-heavy
    s2 = prs.slides.add_slide(prs.slide_layouts[6])
    tb = s2.shapes.add_textbox(Inches(1), Inches(1), Inches(8), Inches(4))
    tb.text_frame.text = " ".join(["word"] * 150)
    tb.text_frame.paragraphs[0].runs[0].font.size = Pt(8)
    # 3: duplicate title
    s3 = prs.slides.add_slide(prs.slide_layouts[5])
    s3.shapes.title.text = "Welcome"
    path = tmp_path / "sample.pptx"
    prs.save(path)
    return path


def test_basic_counts(deck):
    r = analyze_file(deck)
    assert r.slide_count == 3
    assert r.slides_with_notes == 1
    assert r.slides[0].title == "Welcome"
    assert r.slides[1].words == 150


def test_flags_issues(deck):
    r = analyze_file(deck)
    msgs = [i.message for i in r.slides[1].issues]
    assert any("No slide title" in m for m in msgs)
    assert any("Text-heavy" in m for m in msgs)
    assert any("Small font" in m for m in msgs)
    assert any("Duplicate title" in i.message for i in r.deck_issues)
    assert 0 <= r.score < 100


def test_cli_json_and_fail_under(deck, capsys):
    assert main([str(deck), "-f", "json"]) == 0
    assert json.loads(capsys.readouterr().out)["slide_count"] == 3
    assert main([str(deck), "--fail-under", "100"]) == 1


def test_cli_missing_file(tmp_path, capsys):
    assert main([str(tmp_path / "nope.pptx")]) == 1
