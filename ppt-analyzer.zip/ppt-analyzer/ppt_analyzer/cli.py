from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .analyzer import analyze_file
from .formatters import FORMATTERS


def _collect(paths: list[str]) -> list[Path]:
    files: list[Path] = []
    for p in map(Path, paths):
        if p.is_dir():
            files += sorted(p.rglob("*.pptx"))
        else:
            files.append(p)
    return [f for f in files if not f.name.startswith("~$")]  # skip Office lock files


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(
        prog="ppt-analyzer", description="Analyze PowerPoint (.pptx) files."
    )
    ap.add_argument("paths", nargs="+", help=".pptx files or folders containing them")
    ap.add_argument("-f", "--format", choices=FORMATTERS, default="text")
    ap.add_argument("-o", "--output", help="write the report to this file")
    ap.add_argument("--max-words", type=int, default=120, help="words per slide before a warning")
    ap.add_argument("--min-font", type=float, default=12.0, help="smallest allowed font size (pt)")
    ap.add_argument("--fail-under", type=int, help="exit with code 1 if any score is below this")
    ap.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    args = ap.parse_args(argv)

    files = _collect(args.paths)
    if not files:
        print("No .pptx files found.", file=sys.stderr)
        return 2

    chunks, reports, failed = [], [], False
    for f in files:
        try:
            report = analyze_file(f, args.max_words, args.min_font)
        except Exception as exc:  # corrupt / not a pptx
            print(f"Could not read {f}: {exc}", file=sys.stderr)
            failed = True
            continue
        reports.append(report)
        chunks.append(FORMATTERS[args.format](report))
        if args.fail_under is not None and report.score < args.fail_under:
            failed = True

    if args.format == "json":  # always valid JSON: one object, or a list for many files
        data = [r.to_dict() for r in reports]
        output = json.dumps(data[0] if len(data) == 1 else data, indent=2)
    else:
        output = "\n".join(chunks)
    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
    else:
        print(output)
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
