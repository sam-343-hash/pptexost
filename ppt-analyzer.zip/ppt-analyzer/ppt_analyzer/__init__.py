"""ppt-analyzer: analyze PowerPoint (.pptx) files for content and quality issues."""

from .analyzer import DeckReport, SlideReport, analyze_file

__all__ = ["analyze_file", "DeckReport", "SlideReport"]
__version__ = "1.0.0"
