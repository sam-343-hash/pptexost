"""Render a DeckReport as text, markdown or JSON."""

from __future__ import annotations

import json

from .analyzer import DeckReport


def _summary_rows(r: DeckReport) -> list[tuple[str, str]]:
    rows = [
        ("Slides", str(r.slide_count)),
        ("Total words", str(r.total_words)),
        ("Avg words / slide", str(r.avg_words_per_slide)),
        ("Images / charts / tables", f"{r.total_images} / {r.total_charts} / {r.total_tables}"),
        ("Slides with notes", f"{r.slides_with_notes}/{r.slide_count}"),
        ("Est. speaking time", f"{r.est_minutes} min"),
        ("Reading ease", "n/a" if r.reading_ease is None else str(r.reading_ease)),
        ("Fonts", ", ".join(r.fonts) or "theme default"),
        ("Quality score", f"{r.score}/100"),
    ]
    return rows


def to_json(r: DeckReport) -> str:
    return json.dumps(r.to_dict(), indent=2)


def to_text(r: DeckReport) -> str:
    out = [f"== {r.file} ==", ""]
    width = max(len(k) for k, _ in _summary_rows(r))
    out += [f"{k:<{width}} : {v}" for k, v in _summary_rows(r)]
    if r.deck_issues:
        out += ["", "Deck issues:"]
        out += [f"  [{i.severity}] {i.message}" for i in r.deck_issues]
    out += ["", "Slides:"]
    for s in r.slides:
        title = s.title or "(no title)"
        out.append(f"  {s.number:>3}. {title[:50]:<50} {s.words:>4}w  {s.images}img")
        out += [f"       [{i.severity}] {i.message}" for i in s.issues]
    return "\n".join(out) + "\n"


def to_markdown(r: DeckReport) -> str:
    out = [f"# Analysis: {r.file}", "", "| Metric | Value |", "|---|---|"]
    out += [f"| {k} | {v} |" for k, v in _summary_rows(r)]
    if r.deck_issues:
        out += ["", "## Deck issues", ""]
        out += [f"- **{i.severity}**: {i.message}" for i in r.deck_issues]
    out += [
        "",
        "## Slides",
        "",
        "| # | Title | Words | Images | Notes | Issues |",
        "|---|---|---|---|---|---|",
    ]
    for s in r.slides:
        issues = "<br>".join(i.message for i in s.issues) or "-"
        title = (s.title or "_(none)_").replace("|", "\\|")
        out.append(
            f"| {s.number} | {title} | {s.words} | {s.images} | {s.notes_words} | {issues} |"
        )
    return "\n".join(out) + "\n"


FORMATTERS = {"text": to_text, "json": to_json, "markdown": to_markdown}
