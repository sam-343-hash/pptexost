"""Core analysis logic. Only depends on python-pptx."""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Iterator

from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE

WORDS_PER_MINUTE = 130  # typical presentation speaking pace
WORD_RE = re.compile(r"[A-Za-z0-9']+")


@dataclass
class Issue:
    severity: str  # "warning" or "info"
    message: str


@dataclass
class SlideReport:
    number: int
    title: str
    layout: str
    words: int = 0
    paragraphs: int = 0
    images: int = 0
    charts: int = 0
    tables: int = 0
    videos: int = 0
    shapes: int = 0
    notes_words: int = 0
    min_font_pt: float | None = None
    images_missing_alt: int = 0
    issues: list[Issue] = field(default_factory=list)


@dataclass
class DeckReport:
    file: str
    slide_count: int
    total_words: int
    avg_words_per_slide: float
    total_images: int
    total_charts: int
    total_tables: int
    slides_with_notes: int
    fonts: dict[str, int]
    reading_ease: float | None
    est_minutes: float
    score: int
    slides: list[SlideReport]
    deck_issues: list[Issue] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)


# --------------------------------------------------------------------------- helpers


def _walk(shapes) -> Iterator:
    """Yield every shape, descending into groups."""
    for shape in shapes:
        yield shape
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from _walk(shape.shapes)


def _alt_text(shape) -> str:
    nodes = shape._element.xpath(".//p:cNvPr")
    if not nodes:
        return ""
    return (nodes[0].get("descr") or "").strip()


def _count_words(text: str) -> int:
    return len(WORD_RE.findall(text))


def _syllables(word: str) -> int:
    word = word.lower()
    groups = re.findall(r"[aeiouy]+", word)
    count = len(groups)
    if word.endswith("e") and not word.endswith("le") and count > 1:
        count -= 1
    return max(count, 1)


def flesch_reading_ease(text: str) -> float | None:
    """Flesch reading ease; higher is easier. None if there is too little text."""
    words = WORD_RE.findall(text)
    sentences = [s for s in re.split(r"[.!?\n]+", text) if WORD_RE.search(s)]
    if len(words) < 30 or not sentences:
        return None
    syllables = sum(_syllables(w) for w in words)
    score = 206.835 - 1.015 * (len(words) / len(sentences)) - 84.6 * (syllables / len(words))
    return round(max(min(score, 120.0), -50.0), 1)


def _text_frames(slide) -> Iterator[tuple[object, object]]:
    """Yield (shape, text_frame) for shapes and table cells."""
    for shape in _walk(slide.shapes):
        if shape.has_text_frame:
            yield shape, shape.text_frame
        if getattr(shape, "has_table", False) and shape.has_table:
            for row in shape.table.rows:
                for cell in row.cells:
                    yield shape, cell.text_frame


# --------------------------------------------------------------------------- analysis


def analyze_slide(
    slide, number: int, fonts: Counter, texts: list[str], max_words: int, min_font: float
) -> SlideReport:
    title_shape = slide.shapes.title
    title = (title_shape.text_frame.text.strip() if title_shape is not None else "")

    rep = SlideReport(number=number, title=title, layout=slide.slide_layout.name)

    for shape in _walk(slide.shapes):
        rep.shapes += 1
        st = shape.shape_type
        if st == MSO_SHAPE_TYPE.PICTURE:
            rep.images += 1
            if not _alt_text(shape):
                rep.images_missing_alt += 1
        elif st == MSO_SHAPE_TYPE.MEDIA:
            rep.videos += 1
        if getattr(shape, "has_chart", False) and shape.has_chart:
            rep.charts += 1
        if getattr(shape, "has_table", False) and shape.has_table:
            rep.tables += 1

    for _shape, frame in _text_frames(slide):
        for para in frame.paragraphs:
            text = "".join(run.text for run in para.runs).strip()
            if not text:
                continue
            rep.paragraphs += 1
            rep.words += _count_words(text)
            texts.append(text)
            para_size = para.font.size.pt if para.font.size else None
            for run in para.runs:
                if run.font.name:
                    fonts[run.font.name] += len(run.text)
                size = run.font.size.pt if run.font.size else para_size
                if size is not None and (rep.min_font_pt is None or size < rep.min_font_pt):
                    rep.min_font_pt = size

    if slide.has_notes_slide:
        rep.notes_words = _count_words(slide.notes_slide.notes_text_frame.text)

    # ---- per-slide checks
    if not title:
        rep.issues.append(Issue("warning", "No slide title (hurts navigation and accessibility)"))
    if rep.words > max_words:
        rep.issues.append(Issue("warning", f"Text-heavy: {rep.words} words (limit {max_words})"))
    if rep.min_font_pt is not None and rep.min_font_pt < min_font:
        rep.issues.append(
            Issue("warning", f"Small font: {rep.min_font_pt:g}pt (minimum {min_font:g}pt)")
        )
    if rep.images_missing_alt:
        rep.issues.append(
            Issue("warning", f"{rep.images_missing_alt} image(s) missing alt text")
        )
    if rep.words == 0 and not (rep.images or rep.charts or rep.tables or rep.videos):
        rep.issues.append(Issue("info", "Slide appears empty"))
    return rep


def analyze_file(path: str | Path, max_words: int = 120, min_font: float = 12.0) -> DeckReport:
    path = Path(path)
    prs = Presentation(str(path))

    fonts: Counter = Counter()
    texts: list[str] = []
    slides = [
        analyze_slide(s, i, fonts, texts, max_words, min_font)
        for i, s in enumerate(prs.slides, start=1)
    ]

    n = len(slides)
    total_words = sum(s.words for s in slides)
    deck_issues: list[Issue] = []

    # duplicate titles
    seen: dict[str, tuple[str, list[int]]] = {}
    for s in slides:
        if s.title:
            seen.setdefault(s.title.lower(), (s.title, []))[1].append(s.number)
    for title, nums in seen.values():
        if len(nums) > 1:
            deck_issues.append(
                Issue("info", f"Duplicate title '{title}' on slides {', '.join(map(str, nums))}")
            )

    if len(fonts) > 3:
        deck_issues.append(
            Issue("info", f"{len(fonts)} different fonts used; consider limiting to 2-3")
        )
    with_notes = sum(1 for s in slides if s.notes_words > 0)
    if n and with_notes == 0:
        deck_issues.append(Issue("info", "No speaker notes in the deck"))

    reading = flesch_reading_ease(" ".join(texts))
    if reading is not None and reading < 30:
        deck_issues.append(
            Issue("info", f"Text is hard to read (Flesch score {reading}); simplify wording")
        )

    est_minutes = round(
        sum((s.notes_words or s.words) for s in slides) / WORDS_PER_MINUTE, 1
    )

    # score: start at 100, subtract for warnings (capped per slide) and info items
    penalty = 0
    for s in slides:
        penalty += min(sum(8 if i.severity == "warning" else 1 for i in s.issues), 20)
    penalty += len(deck_issues) * 2
    score = max(0, round(100 - (penalty / n if n else 0) * 3 - len(deck_issues) * 2))

    return DeckReport(
        file=path.name,
        slide_count=n,
        total_words=total_words,
        avg_words_per_slide=round(total_words / n, 1) if n else 0.0,
        total_images=sum(s.images for s in slides),
        total_charts=sum(s.charts for s in slides),
        total_tables=sum(s.tables for s in slides),
        slides_with_notes=with_notes,
        fonts=dict(fonts.most_common()),
        reading_ease=reading,
        est_minutes=est_minutes,
        score=score,
        slides=slides,
        deck_issues=deck_issues,
    )
